package com.innoq.lab.twaddle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwaddleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwaddleApplication.class, args);
	}
}
